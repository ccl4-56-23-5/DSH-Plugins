# 鲸鱼娘插件仓库 1.1.1

管理 [ccl4-56-23-5/DSH-Plugins](https://github.com/ccl4-56-23-5/DSH-Plugins) 的 DSH 插件。入口位于左上角“使用统计”下方。

## 本版修复

- 安装返回后重新读取宿主版本和本地安装源的 SHA-256，确认目标包后才显示完成。未能确认的结果显示“待核对”，不会自动重复安装。
- 自更新或热重载中断回执时，对照目标版本和源包哈希恢复结果；旧实例退出后不再写入过时回执。保留操作历史。
- 操作区分进行中、完成、失败、待核对；提取完整日志中的 ENOENT 等根因，并可展开诊断，不再只展示下载进度前400字符。
- 安装前检查已安装插件的绝对本地源文件；缺失时指出插件及路径，在调用包管理器前停止。源包缓存位于 DSH_HOME/repo-manager，请保留当前安装依赖的包。
- 6张内置卡片与6种原版图标，补齐故事中控台的名称、说明和图标。

缓存优先展示，后台核对 GitHub；断网保留列表。磁盘目录为 DSH_HOME/repo-manager/catalog-v1.json，浏览器快照只用于显示，不作为安装依据。空/坏缓存、并发刷新和错误保留均有检查。

## 安装与更新

[下载 Release](https://github.com/ccl4-56-23-5/DSH-Plugins/releases/tag/repo-manager-v1.1.1)。Windows ZIP包含 TGZ、清单、SHA-256和本说明，无独立运行时依赖。

已安装用户在仓库中“检测状态与更新”，找到本卡片点击“更新插件”，再点“确认执行”。提交后等待最近操作结果；下载、DSH安装和读回验证各需时间。首次安装可在 DSH 原生插件页添加 Release TGZ 地址。

如提示本地安装源不存在，检查完整路径并恢复安装包或通过宿主重新安装相关插件。不要仅删除依赖清单/锁文件。失败、待核对、需重启和配置覆盖分别显示。宿主要求重启时由用户安排，不自动中断会话。

## 运行状态与保护

红灯表示宿主入口缺失或非active；黄灯表示运行正常但待更新；绿灯需要当前发布版本已核对且所有入口active；灰色表示未安装、停用或暂不能确认。安装完成与业务功能验收分别判断。

只访问本仓库正式Release；下载前重新核对版本，下载后验证大小、哈希、包身份与安装脚本。保留配置及原停用状态，不降级。控制桥和仓库自身的停用在宿主原生插件页管理。不会请求GitHub令牌或发送会话内容。

## 开发

Node22及以上。运行 `node --test test/manager.test.mjs test/cache.test.mjs test/health.test.mjs test/operations.test.mjs`，构建 `node scripts/build-release.mjs`。客户端源为 src/client.js，构建注入透明图标生成 lib/client.js。

[验证范围](VALIDATION.md)。设计参考 [dsh-market](https://github.com/dsh-market/dsh-market)，实现独立。